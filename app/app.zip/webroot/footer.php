<footer class="first_footer">
	<section>
		<h3><b>PMS</b></h3>
		<p><b>+841234567890</b><br/><br>
		Nhà C9, Số 1 Đại Cồ Việt,<br/>Hai Bà Trưng, Hà Nội<br />wtf_pms@gmail.com</p>
	</section>
	<section>
		<h3>Connect with us</h3>
		<ul class="social">
			<li><a href="https://www.facebook.com/" target="_blank"><img src="http://www.w3newbie.com/wp-content/uploads/facebook1.png" /></a></li>
			<li><a href="https://github.com/AnhtuTa/pms" target="_blank"><?php echo $this->Html->image('github.png', array('alt' => 'logo BKHN', 'height' => '120px')); ?></a></li>
			<li><a href="https://twitter.com/" target="_blank"><img src="http://www.w3newbie.com/wp-content/uploads/twitter1.png" /></a></li>
			<li><a href="https://www.youtube.com/" target="_blank"><img src="http://www.w3newbie.com/wp-content/uploads/youtube1.png" /></a></li>
		</ul>
	</section>
	<section>
		<?php echo $this->Html->image('cong_parabol.png', array('alt' => 'logo BKHN', 'height' => '120px')); ?>
	</section>
</footer>
<footer class="second_footer">
	<p>&copy; Copyright - PMS, 2018</p>
</footer>