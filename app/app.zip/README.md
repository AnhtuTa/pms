# Project3_pms
Project management system

Project này dùng framework CakePHP 2.7.2
Cách cài đặt: 
1. Download CakePHP 2.7.2 về và giải nén ở thư mục cài xampp: htdocs
2. Cấu hình cho Cakephp, xem hướng dẫn tại: http://nongdanit.info/php-mysql/huong-dan-cai-dat-cakephp.html
Nếu ko cấu hình cũng đc vì t đã cấu hình rồi
3. Thay thế thư mục app trong thư mục CakePHP vừa giải nén bằng tất cả các file và thư mục ở đây
4. Cần cài đặt NodeJS express, socket.io
5. Cần tạo 1 database như trong script .sql
6. Done!
