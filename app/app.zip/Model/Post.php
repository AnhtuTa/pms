
<?php
class Post extends AppModel {
    var $name = "Post";//tên của model
}