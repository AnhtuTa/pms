<?php
class Comment extends AppModel {
    var $name = "Comment";//tên của model
}