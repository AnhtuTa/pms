
<?php
class Demo extends AppModel {
    var $name = "Demo";//tên của model
    public $useTable = false; // This model does not use a database table
}