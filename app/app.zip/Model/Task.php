
<?php
class Task extends AppModel {
    var $name = "Task";//tên của model
    //public $useTable = false; // This model does not use a database table
}